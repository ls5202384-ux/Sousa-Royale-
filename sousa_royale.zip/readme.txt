Sousa Royale — Protótipo Fantasia

Como jogar localmente:
1. Extrai o conteúdo do ZIP para uma pasta.
2. Abre index.html num navegador moderno (Chrome, Firefox, Edge).
3. Escolhe 8 cartas no deck e clica "Iniciar".
4. Usa teclas 1–8 para jogar as cartas.

Como publicar online:
- GitHub Pages: https://pages.github.com/
  1. Cria um repositório e faz upload de index.html.
  2. Ativa GitHub Pages nas definições do repositório.
  3. Usa o link fornecido pelo GitHub para jogar online.
- itch.io: https://itch.io
  1. Cria conta e projeto.
  2. Faz upload de index.html como HTML5 game.
  3. Publica e obtém link online.
